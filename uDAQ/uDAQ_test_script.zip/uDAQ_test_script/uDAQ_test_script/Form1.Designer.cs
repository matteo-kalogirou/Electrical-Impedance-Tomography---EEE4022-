﻿namespace uDAQ_test_script
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        // User provided variables
        EDREApi usb30d = new EDREApi();
        private int AdcSN;
        private int OutFreq;
        private int InFreq;
        private int Unread;
        private int readSamples;
        private int samplesPchip;
        private int[] ChList = new int[32] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 };
        private int[] GainList = new int[32] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        private int[] InBuff = new int[10000000];
        private int[] OutBuff = new int[32768];//2*16*1024
        private int[] OutBuf = new int[8192]; //2*16*256
        private int[] OutBu = new int[16384]; //2*16*512
        System.IO.StreamWriter fd;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel1 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblADCDes = new System.Windows.Forms.Label();
            this.lblADCSN = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblUnreadSamples = new System.Windows.Forms.Label();
            this.lblUnwritten = new System.Windows.Forms.Label();
            this.nudSamples = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.nudInRate = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nudOutRate = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.tbFileName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbSave2File = new System.Windows.Forms.CheckBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cbOut16 = new System.Windows.Forms.CheckBox();
            this.cbOut15 = new System.Windows.Forms.CheckBox();
            this.cbOut14 = new System.Windows.Forms.CheckBox();
            this.cbOut13 = new System.Windows.Forms.CheckBox();
            this.cbOut12 = new System.Windows.Forms.CheckBox();
            this.cbOut11 = new System.Windows.Forms.CheckBox();
            this.cbOut10 = new System.Windows.Forms.CheckBox();
            this.cbOut9 = new System.Windows.Forms.CheckBox();
            this.cbOut8 = new System.Windows.Forms.CheckBox();
            this.cbOut7 = new System.Windows.Forms.CheckBox();
            this.cbOut6 = new System.Windows.Forms.CheckBox();
            this.cbOut5 = new System.Windows.Forms.CheckBox();
            this.cbOut4 = new System.Windows.Forms.CheckBox();
            this.cbOut3 = new System.Windows.Forms.CheckBox();
            this.cbOut2 = new System.Windows.Forms.CheckBox();
            this.cbOut1 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.incFrame = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSamples)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutRate)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblADCDes);
            this.groupBox1.Controls.Add(this.lblADCSN);
            this.groupBox1.Location = new System.Drawing.Point(1, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(219, 106);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ADC device information";
            // 
            // lblADCDes
            // 
            this.lblADCDes.AutoSize = true;
            this.lblADCDes.Location = new System.Drawing.Point(11, 63);
            this.lblADCDes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblADCDes.Name = "lblADCDes";
            this.lblADCDes.Size = new System.Drawing.Size(63, 13);
            this.lblADCDes.TabIndex = 1;
            this.lblADCDes.Text = "Description:";
            // 
            // lblADCSN
            // 
            this.lblADCSN.AutoSize = true;
            this.lblADCSN.Location = new System.Drawing.Point(9, 30);
            this.lblADCSN.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblADCSN.Name = "lblADCSN";
            this.lblADCSN.Size = new System.Drawing.Size(74, 13);
            this.lblADCSN.TabIndex = 0;
            this.lblADCSN.Text = "Serial number:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblUnreadSamples);
            this.groupBox2.Controls.Add(this.lblUnwritten);
            this.groupBox2.Controls.Add(this.nudSamples);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.nudInRate);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.nudOutRate);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnBrowse);
            this.groupBox2.Controls.Add(this.tbFileName);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.cbSave2File);
            this.groupBox2.Location = new System.Drawing.Point(5, 212);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(288, 311);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Acquisition settings";
            // 
            // lblUnreadSamples
            // 
            this.lblUnreadSamples.AutoSize = true;
            this.lblUnreadSamples.Location = new System.Drawing.Point(5, 200);
            this.lblUnreadSamples.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUnreadSamples.Name = "lblUnreadSamples";
            this.lblUnreadSamples.Size = new System.Drawing.Size(86, 13);
            this.lblUnreadSamples.TabIndex = 7;
            this.lblUnreadSamples.Text = "Unread samples:";
            // 
            // lblUnwritten
            // 
            this.lblUnwritten.AutoSize = true;
            this.lblUnwritten.Location = new System.Drawing.Point(5, 171);
            this.lblUnwritten.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUnwritten.Name = "lblUnwritten";
            this.lblUnwritten.Size = new System.Drawing.Size(96, 13);
            this.lblUnwritten.TabIndex = 12;
            this.lblUnwritten.Text = "Unwritten samples:";
            // 
            // nudSamples
            // 
            this.nudSamples.Location = new System.Drawing.Point(116, 142);
            this.nudSamples.Margin = new System.Windows.Forms.Padding(2);
            this.nudSamples.Maximum = new decimal(new int[] {
            2000000,
            0,
            0,
            0});
            this.nudSamples.Name = "nudSamples";
            this.nudSamples.Size = new System.Drawing.Size(90, 20);
            this.nudSamples.TabIndex = 11;
            this.nudSamples.Value = new decimal(new int[] {
            3200,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 140);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Number of samples:";
            // 
            // nudInRate
            // 
            this.nudInRate.Location = new System.Drawing.Point(116, 116);
            this.nudInRate.Margin = new System.Windows.Forms.Padding(2);
            this.nudInRate.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.nudInRate.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudInRate.Name = "nudInRate";
            this.nudInRate.Size = new System.Drawing.Size(90, 20);
            this.nudInRate.TabIndex = 6;
            this.nudInRate.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Sample rate:";
            // 
            // nudOutRate
            // 
            this.nudOutRate.Increment = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.nudOutRate.Location = new System.Drawing.Point(116, 92);
            this.nudOutRate.Margin = new System.Windows.Forms.Padding(2);
            this.nudOutRate.Maximum = new decimal(new int[] {
            65536,
            0,
            0,
            0});
            this.nudOutRate.Minimum = new decimal(new int[] {
            512,
            0,
            0,
            0});
            this.nudOutRate.Name = "nudOutRate";
            this.nudOutRate.Size = new System.Drawing.Size(90, 20);
            this.nudOutRate.TabIndex = 4;
            this.nudOutRate.Value = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 92);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Output rate:";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(219, 68);
            this.btnBrowse.Margin = new System.Windows.Forms.Padding(2);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(56, 19);
            this.btnBrowse.TabIndex = 2;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // tbFileName
            // 
            this.tbFileName.Location = new System.Drawing.Point(8, 68);
            this.tbFileName.Margin = new System.Windows.Forms.Padding(2);
            this.tbFileName.Name = "tbFileName";
            this.tbFileName.Size = new System.Drawing.Size(198, 20);
            this.tbFileName.TabIndex = 1;
            this.tbFileName.Text = "C:\\Users\\user\\Desktop\\Results\\frame";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Output filename:";
            // 
            // cbSave2File
            // 
            this.cbSave2File.AutoSize = true;
            this.cbSave2File.Checked = true;
            this.cbSave2File.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbSave2File.Location = new System.Drawing.Point(5, 28);
            this.cbSave2File.Margin = new System.Windows.Forms.Padding(2);
            this.cbSave2File.Name = "cbSave2File";
            this.cbSave2File.Size = new System.Drawing.Size(105, 17);
            this.cbSave2File.TabIndex = 0;
            this.cbSave2File.Text = "Log output to file";
            this.cbSave2File.UseVisualStyleBackColor = true;
            this.cbSave2File.CheckStateChanged += new System.EventHandler(this.cbSave2File_CheckStateChanged);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(224, 11);
            this.btnStart.Margin = new System.Windows.Forms.Padding(2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(56, 19);
            this.btnStart.TabIndex = 5;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(224, 44);
            this.btnStop.Margin = new System.Windows.Forms.Padding(2);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(56, 19);
            this.btnStop.TabIndex = 4;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(224, 77);
            this.btnExit.Margin = new System.Windows.Forms.Padding(2);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(56, 19);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cbOut16);
            this.groupBox3.Controls.Add(this.cbOut15);
            this.groupBox3.Controls.Add(this.cbOut14);
            this.groupBox3.Controls.Add(this.cbOut13);
            this.groupBox3.Controls.Add(this.cbOut12);
            this.groupBox3.Controls.Add(this.cbOut11);
            this.groupBox3.Controls.Add(this.cbOut10);
            this.groupBox3.Controls.Add(this.cbOut9);
            this.groupBox3.Controls.Add(this.cbOut8);
            this.groupBox3.Controls.Add(this.cbOut7);
            this.groupBox3.Controls.Add(this.cbOut6);
            this.groupBox3.Controls.Add(this.cbOut5);
            this.groupBox3.Controls.Add(this.cbOut4);
            this.groupBox3.Controls.Add(this.cbOut3);
            this.groupBox3.Controls.Add(this.cbOut2);
            this.groupBox3.Controls.Add(this.cbOut1);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.chart1);
            this.groupBox3.Location = new System.Drawing.Point(293, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(718, 527);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Graph display";
            // 
            // cbOut16
            // 
            this.cbOut16.AutoSize = true;
            this.cbOut16.Checked = true;
            this.cbOut16.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut16.Location = new System.Drawing.Point(406, 46);
            this.cbOut16.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut16.Name = "cbOut16";
            this.cbOut16.Size = new System.Drawing.Size(61, 17);
            this.cbOut16.TabIndex = 21;
            this.cbOut16.Text = "Out_16";
            this.cbOut16.UseVisualStyleBackColor = true;
            this.cbOut16.CheckStateChanged += new System.EventHandler(this.cbOut16_CheckStateChanged);
            // 
            // cbOut15
            // 
            this.cbOut15.AutoSize = true;
            this.cbOut15.Checked = true;
            this.cbOut15.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut15.Location = new System.Drawing.Point(322, 90);
            this.cbOut15.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut15.Name = "cbOut15";
            this.cbOut15.Size = new System.Drawing.Size(61, 17);
            this.cbOut15.TabIndex = 20;
            this.cbOut15.Text = "Out_15";
            this.cbOut15.UseVisualStyleBackColor = true;
            this.cbOut15.CheckStateChanged += new System.EventHandler(this.cbOut15_CheckStateChanged);
            // 
            // cbOut14
            // 
            this.cbOut14.AutoSize = true;
            this.cbOut14.Checked = true;
            this.cbOut14.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut14.Location = new System.Drawing.Point(322, 68);
            this.cbOut14.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut14.Name = "cbOut14";
            this.cbOut14.Size = new System.Drawing.Size(61, 17);
            this.cbOut14.TabIndex = 19;
            this.cbOut14.Text = "Out_14";
            this.cbOut14.UseVisualStyleBackColor = true;
            this.cbOut14.CheckStateChanged += new System.EventHandler(this.cbOut14_CheckStateChanged);
            // 
            // cbOut13
            // 
            this.cbOut13.AutoSize = true;
            this.cbOut13.Checked = true;
            this.cbOut13.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut13.Location = new System.Drawing.Point(322, 46);
            this.cbOut13.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut13.Name = "cbOut13";
            this.cbOut13.Size = new System.Drawing.Size(61, 17);
            this.cbOut13.TabIndex = 18;
            this.cbOut13.Text = "Out_13";
            this.cbOut13.UseVisualStyleBackColor = true;
            this.cbOut13.CheckStateChanged += new System.EventHandler(this.cbOut13_CheckStateChanged);
            // 
            // cbOut12
            // 
            this.cbOut12.AutoSize = true;
            this.cbOut12.Checked = true;
            this.cbOut12.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut12.Location = new System.Drawing.Point(238, 90);
            this.cbOut12.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut12.Name = "cbOut12";
            this.cbOut12.Size = new System.Drawing.Size(61, 17);
            this.cbOut12.TabIndex = 17;
            this.cbOut12.Text = "Out_12";
            this.cbOut12.UseVisualStyleBackColor = true;
            this.cbOut12.CheckStateChanged += new System.EventHandler(this.cbOut12_CheckStateChanged);
            // 
            // cbOut11
            // 
            this.cbOut11.AutoSize = true;
            this.cbOut11.Checked = true;
            this.cbOut11.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut11.Location = new System.Drawing.Point(238, 68);
            this.cbOut11.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut11.Name = "cbOut11";
            this.cbOut11.Size = new System.Drawing.Size(61, 17);
            this.cbOut11.TabIndex = 16;
            this.cbOut11.Text = "Out_11";
            this.cbOut11.UseVisualStyleBackColor = true;
            this.cbOut11.CheckStateChanged += new System.EventHandler(this.cbOut11_CheckStateChanged);
            // 
            // cbOut10
            // 
            this.cbOut10.AutoSize = true;
            this.cbOut10.Checked = true;
            this.cbOut10.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut10.Location = new System.Drawing.Point(238, 46);
            this.cbOut10.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut10.Name = "cbOut10";
            this.cbOut10.Size = new System.Drawing.Size(61, 17);
            this.cbOut10.TabIndex = 15;
            this.cbOut10.Text = "Out_10";
            this.cbOut10.UseVisualStyleBackColor = true;
            this.cbOut10.CheckStateChanged += new System.EventHandler(this.cbOut10_CheckStateChanged);
            // 
            // cbOut9
            // 
            this.cbOut9.AutoSize = true;
            this.cbOut9.Checked = true;
            this.cbOut9.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut9.Location = new System.Drawing.Point(160, 90);
            this.cbOut9.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut9.Name = "cbOut9";
            this.cbOut9.Size = new System.Drawing.Size(55, 17);
            this.cbOut9.TabIndex = 14;
            this.cbOut9.Text = "Out_9";
            this.cbOut9.UseVisualStyleBackColor = true;
            this.cbOut9.CheckStateChanged += new System.EventHandler(this.cbOut9_CheckStateChanged);
            // 
            // cbOut8
            // 
            this.cbOut8.AutoSize = true;
            this.cbOut8.Checked = true;
            this.cbOut8.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut8.Location = new System.Drawing.Point(160, 68);
            this.cbOut8.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut8.Name = "cbOut8";
            this.cbOut8.Size = new System.Drawing.Size(55, 17);
            this.cbOut8.TabIndex = 13;
            this.cbOut8.Text = "Out_8";
            this.cbOut8.UseVisualStyleBackColor = true;
            this.cbOut8.CheckStateChanged += new System.EventHandler(this.cbOut8_CheckStateChanged);
            // 
            // cbOut7
            // 
            this.cbOut7.AutoSize = true;
            this.cbOut7.Checked = true;
            this.cbOut7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut7.Location = new System.Drawing.Point(160, 46);
            this.cbOut7.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut7.Name = "cbOut7";
            this.cbOut7.Size = new System.Drawing.Size(55, 17);
            this.cbOut7.TabIndex = 12;
            this.cbOut7.Text = "Out_7";
            this.cbOut7.UseVisualStyleBackColor = true;
            this.cbOut7.CheckStateChanged += new System.EventHandler(this.cbOut7_CheckStateChanged);
            // 
            // cbOut6
            // 
            this.cbOut6.AutoSize = true;
            this.cbOut6.Checked = true;
            this.cbOut6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut6.Location = new System.Drawing.Point(82, 90);
            this.cbOut6.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut6.Name = "cbOut6";
            this.cbOut6.Size = new System.Drawing.Size(55, 17);
            this.cbOut6.TabIndex = 11;
            this.cbOut6.Text = "Out_6";
            this.cbOut6.UseVisualStyleBackColor = true;
            this.cbOut6.CheckStateChanged += new System.EventHandler(this.cbOut6_CheckStateChanged);
            // 
            // cbOut5
            // 
            this.cbOut5.AutoSize = true;
            this.cbOut5.Checked = true;
            this.cbOut5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut5.Location = new System.Drawing.Point(82, 68);
            this.cbOut5.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut5.Name = "cbOut5";
            this.cbOut5.Size = new System.Drawing.Size(55, 17);
            this.cbOut5.TabIndex = 10;
            this.cbOut5.Text = "Out_5";
            this.cbOut5.UseVisualStyleBackColor = true;
            this.cbOut5.CheckStateChanged += new System.EventHandler(this.cbOut5_CheckStateChanged);
            // 
            // cbOut4
            // 
            this.cbOut4.AutoSize = true;
            this.cbOut4.Checked = true;
            this.cbOut4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut4.Location = new System.Drawing.Point(82, 46);
            this.cbOut4.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut4.Name = "cbOut4";
            this.cbOut4.Size = new System.Drawing.Size(55, 17);
            this.cbOut4.TabIndex = 9;
            this.cbOut4.Text = "Out_4";
            this.cbOut4.UseVisualStyleBackColor = true;
            this.cbOut4.CheckStateChanged += new System.EventHandler(this.cbOut4_CheckStateChanged);
            // 
            // cbOut3
            // 
            this.cbOut3.AutoSize = true;
            this.cbOut3.Checked = true;
            this.cbOut3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut3.Location = new System.Drawing.Point(4, 89);
            this.cbOut3.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut3.Name = "cbOut3";
            this.cbOut3.Size = new System.Drawing.Size(55, 17);
            this.cbOut3.TabIndex = 3;
            this.cbOut3.Text = "Out_3";
            this.cbOut3.UseVisualStyleBackColor = true;
            this.cbOut3.CheckStateChanged += new System.EventHandler(this.cbOut3_CheckStateChanged);
            // 
            // cbOut2
            // 
            this.cbOut2.AutoSize = true;
            this.cbOut2.Checked = true;
            this.cbOut2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut2.Location = new System.Drawing.Point(4, 68);
            this.cbOut2.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut2.Name = "cbOut2";
            this.cbOut2.Size = new System.Drawing.Size(55, 17);
            this.cbOut2.TabIndex = 2;
            this.cbOut2.Text = "Out_2";
            this.cbOut2.UseVisualStyleBackColor = true;
            this.cbOut2.CheckStateChanged += new System.EventHandler(this.cbOut2_CheckStateChanged);
            // 
            // cbOut1
            // 
            this.cbOut1.AutoSize = true;
            this.cbOut1.Checked = true;
            this.cbOut1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbOut1.Location = new System.Drawing.Point(4, 46);
            this.cbOut1.Margin = new System.Windows.Forms.Padding(2);
            this.cbOut1.Name = "cbOut1";
            this.cbOut1.Size = new System.Drawing.Size(55, 17);
            this.cbOut1.TabIndex = 1;
            this.cbOut1.Text = "Out_1";
            this.cbOut1.UseVisualStyleBackColor = true;
            this.cbOut1.CheckStateChanged += new System.EventHandler(this.cbOut1_CheckStateChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 29);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Display outputs:";
            // 
            // chart1
            // 
            chartArea1.AxisX.CustomLabels.Add(customLabel1);
            chartArea1.AxisX.Title = "Sample number";
            chartArea1.AxisY.Title = "Amplitude [in V]";
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(4, 123);
            this.chart1.Margin = new System.Windows.Forms.Padding(2);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Bright;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(696, 374);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            title1.Name = "Signal Plot";
            title1.Text = "Signal Plot";
            this.chart1.Titles.Add(title1);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // incFrame
            // 
            this.incFrame.Location = new System.Drawing.Point(16, 147);
            this.incFrame.Name = "incFrame";
            this.incFrame.Size = new System.Drawing.Size(81, 35);
            this.incFrame.TabIndex = 6;
            this.incFrame.Text = "Increment Frame";
            this.incFrame.UseVisualStyleBackColor = true;
            this.incFrame.Click += new System.EventHandler(this.GetFrames_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "System Idle...";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(117, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(79, 35);
            this.button1.TabIndex = 16;
            this.button1.Text = "Reset frame";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 555);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.incFrame);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudSamples)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudInRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutRate)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblADCDes;
        private System.Windows.Forms.Label lblADCSN;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblUnreadSamples;
        private System.Windows.Forms.Label lblUnwritten;
        private System.Windows.Forms.NumericUpDown nudSamples;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudInRate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown nudOutRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox tbFileName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox cbSave2File;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cbOut16;
        private System.Windows.Forms.CheckBox cbOut15;
        private System.Windows.Forms.CheckBox cbOut14;
        private System.Windows.Forms.CheckBox cbOut13;
        private System.Windows.Forms.CheckBox cbOut12;
        private System.Windows.Forms.CheckBox cbOut11;
        private System.Windows.Forms.CheckBox cbOut10;
        private System.Windows.Forms.CheckBox cbOut9;
        private System.Windows.Forms.CheckBox cbOut8;
        private System.Windows.Forms.CheckBox cbOut7;
        private System.Windows.Forms.CheckBox cbOut6;
        private System.Windows.Forms.CheckBox cbOut5;
        private System.Windows.Forms.CheckBox cbOut4;
        private System.Windows.Forms.CheckBox cbOut3;
        private System.Windows.Forms.CheckBox cbOut2;
        private System.Windows.Forms.CheckBox cbOut1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.Button incFrame;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
    }
}

