﻿//////////////////////////////////////////////////////////////////////////
//  Author: Ezra America                                                //
//  Description: Standard control of an Eagle Tech. uDAQ ADC board      //
//////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using EDRE;

namespace uDAQ_test_script
{
    public partial class Form1 : Form
    {
        int frame = 0;
        string path = "C:\\Users\\user\\Desktop\\Results\\";
        public Form1()
        {
            InitializeComponent();
        }

        //===================================================
        // Loading Form design at startup.                  =
        //===================================================

        private void Form1_Load(object sender, EventArgs e)
        {
            // Retrieve ADC device information
            AdcSN = 1000023582;
            usb30d.SerialNumber = AdcSN;
           
            lblADCSN.Text += AdcSN.ToString();

            lblADCDes.Text += usb30d.Query(100, 0) + " ADC Channels, @ " + usb30d.Query(102, 0) + " Samples/s, " + usb30d.Query(104, 0) + " Bytes FIFO Buffer.";

            // Configure Graph 
            chart1.Series.Clear();
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = true;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = true;

            // At startup, add each output as a chart series
            chart1.Series.Add("Out_1");
            chart1.Series["Out_1"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_2");
            chart1.Series["Out_2"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_3");
            chart1.Series["Out_3"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_4");
            chart1.Series["Out_4"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_5");
            chart1.Series["Out_5"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_6");
            chart1.Series["Out_6"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_7");
            chart1.Series["Out_7"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_8");
            chart1.Series["Out_8"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_9");
            chart1.Series["Out_9"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_10");
            chart1.Series["Out_10"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_11");
            chart1.Series["Out_11"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_12");
            chart1.Series["Out_12"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_13");
            chart1.Series["Out_13"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_14");
            chart1.Series["Out_14"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_15");
            chart1.Series["Out_15"].ChartType = SeriesChartType.FastLine;
            chart1.Series.Add("Out_16");
            chart1.Series["Out_16"].ChartType = SeriesChartType.FastLine;
        }

        //=======================================================
        //  Check that the Log to file checkbox is ticked.      =
        //=======================================================
        private void cbSave2File_CheckStateChanged(object sender, EventArgs e)
        {
            tbFileName.Enabled = cbSave2File.Checked ? true : false;
            btnBrowse.Enabled = cbSave2File.Checked ? true : false;
        }

        //===================================================================
        //  Defining procedure followed when the Browse button is clicked.  =
        //===================================================================
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            tbFileName.Text = saveFileDialog1.FileName;
        }

        //===================================================================
        //  Defining procedure followed when the Start button is clicked.   =
        //===================================================================
        private void btnStart_Click(object sender, EventArgs e)
        {

            // Open Text file for logging if necessary 
            if (cbSave2File.Checked)
            {
                fd = new System.IO.StreamWriter(tbFileName.Text);
            }

            // Configure ADC Device
            InFreq = (int)nudInRate.Value;
            readSamples = (int)nudSamples.Value;
            usb30d.ADConfig(ref InFreq, 256, 1, 1, ChList, GainList, 32);

            // Start DAQ process            
            usb30d.ADStart();
                        
            // Start the timer. after all devices have been setup and enabled
            timer1.Interval = 1;
            timer1.Enabled = true;

            // Cleanup tasks
            cbSave2File.Enabled = false;
            nudInRate.Enabled = false;
            nudOutRate.Enabled = false;
            nudSamples.Enabled = false;
            btnStart.Enabled = false;
            btnExit.Enabled = false;
            btnStop.Enabled = true;

        }

        //===================================================================
        //  Defining procedure followed when the Stop button is clicked.    =
        //===================================================================

        private void btnStop_Click(object sender, EventArgs e)
        {

            timer1.Enabled = false;

            usb30d.ADStop();

            if (cbSave2File.Checked)
            {
                fd.Close();
            }

            // Cleanup tasks
            cbSave2File.Enabled = true;
            nudInRate.Enabled = true;
            nudOutRate.Enabled = true;
            nudSamples.Enabled = true;
            btnExit.Enabled = true;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        //===================================================================
        //  Defining procedure followed when the Exit button is clicked.    =
        //===================================================================

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //===================================================================
        //  Defining timer behaviour                                        =
        //===================================================================

        private void timer1_Tick(object sender, EventArgs e)
        {
            Unread = usb30d.Query(QUERY.ADUNREAD, 0);
            lblUnreadSamples.Text = "Unread Samples: " + Unread.ToString();

            if (Unread >= nudSamples.Value)
            {
                usb30d.ADGetData(InBuff, ref readSamples);
                timer1.Enabled = false;
                usb30d.ADStop();
                this.Invoke(new EventHandler(LogAndPlot_Update));
            }

        }

        //===================================================================
        //  Automatic chart update based on timer                           =
        //===================================================================

        private void LogAndPlot_Update(object sender, EventArgs e)
        {
            int count = 0;
            double Valu = 0;
            if (cbSave2File.Checked)
            {
                //fd.WriteLine(DateTime.Now);
                //fd.Write("Tin = " + (16.0 / (int)nudInRate.Value).ToString() + "s");
                //fd.WriteLine();
               // fd.Write("Tout = " + (1.0 / (int)nudOutRate.Value).ToString() + "s");
                //fd.WriteLine();
            }

            count = 0;
            for (int i = 0; i < readSamples; i += 32)
            {
                // Add points to Output plots
                chart1.Series["Out_1"].Points.AddXY(count, InBuff[i + 0] / 1000000.0);
                chart1.Series["Out_2"].Points.AddXY(count, InBuff[i + 1] / 1000000.0);
                chart1.Series["Out_3"].Points.AddXY(count, InBuff[i + 2] / 1000000.0);
                chart1.Series["Out_4"].Points.AddXY(count, InBuff[i + 3] / 1000000.0);
                chart1.Series["Out_5"].Points.AddXY(count, InBuff[i + 4] / 1000000.0);
                chart1.Series["Out_6"].Points.AddXY(count, InBuff[i + 5] / 1000000.0);
                chart1.Series["Out_7"].Points.AddXY(count, InBuff[i + 6] / 1000000.0);
                chart1.Series["Out_8"].Points.AddXY(count, InBuff[i + 7] / 1000000.0);
                chart1.Series["Out_9"].Points.AddXY(count, InBuff[i + 8] / 1000000.0);
                chart1.Series["Out_10"].Points.AddXY(count, InBuff[i + 9] / 1000000.0);
                chart1.Series["Out_11"].Points.AddXY(count, InBuff[i + 10] / 1000000.0);
                chart1.Series["Out_12"].Points.AddXY(count, InBuff[i + 11] / 1000000.0);
                chart1.Series["Out_13"].Points.AddXY(count, InBuff[i + 12] / 1000000.0);
                chart1.Series["Out_14"].Points.AddXY(count, InBuff[i + 13] / 1000000.0);
                chart1.Series["Out_15"].Points.AddXY(count, InBuff[i + 14] / 1000000.0);
                chart1.Series["Out_16"].Points.AddXY(count, InBuff[i + 15] / 1000000.0);


                if (cbSave2File.Checked)
                {
                    //fd.WriteLine();
                    for (int j = 0; j < 16; j++)
                    {
                        Valu = InBuff[i + j] / 1000000.0;
                        // Log data to file
                        if (j == 15)
                            fd.Write(Valu + " ");
                        else
                            fd.Write(Valu + "; ");
                    }
                    fd.WriteLine();
                }
                count++;
            }
        }

        // Control display of outputs
        private void cbOut1_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_1"].Enabled = cbOut1.Checked ? true : false;
        }

        private void cbOut2_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_2"].Enabled = cbOut2.Checked ? true : false;
        }

        private void cbOut3_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_3"].Enabled = cbOut3.Checked ? true : false;
        }

        private void cbOut4_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_4"].Enabled = cbOut4.Checked ? true : false;
        }

        private void cbOut5_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_5"].Enabled = cbOut5.Checked ? true : false;
        }

        private void cbOut6_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_6"].Enabled = cbOut6.Checked ? true : false;
        }

        private void cbOut7_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_7"].Enabled = cbOut7.Checked ? true : false;
        }

        private void cbOut8_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_8"].Enabled = cbOut8.Checked ? true : false;
        }

        private void cbOut9_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_9"].Enabled = cbOut9.Checked ? true : false;
        }

        private void cbOut10_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_10"].Enabled = cbOut10.Checked ? true : false;
        }

        private void cbOut11_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_11"].Enabled = cbOut11.Checked ? true : false;
        }

        private void cbOut12_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_12"].Enabled = cbOut12.Checked ? true : false;
        }

        private void cbOut13_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_13"].Enabled = cbOut13.Checked ? true : false;
        }

        private void cbOut14_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_14"].Enabled = cbOut14.Checked ? true : false;
        }

        private void cbOut15_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_15"].Enabled = cbOut15.Checked ? true : false;
        }

        private void cbOut16_CheckStateChanged(object sender, EventArgs e)
        {
            chart1.Series["Out_16"].Enabled = cbOut16.Checked ? true : false;
        }

        //Send pulse to increment the frame reading
        private void GetFrames_Click(object sender, EventArgs e)
        {

            usb30d.DIOWrite(0, 1);
            System.Threading.Thread.Sleep(100);
            usb30d.DIOWrite(0, 0);
            System.Threading.Thread.Sleep(100);
            ++frame;
            if (frame > 15)
                frame = 0;

            label6.Text = "Frame: " + frame.ToString();
            tbFileName.Text = path + "frame" + frame.ToString() + ".txt";

        }

        //Send pulse to DIO P1 to reset frames to 0
        private void Button1_Click(object sender, EventArgs e)
        {
            usb30d.DIOWrite(1, 1);
            System.Threading.Thread.Sleep(100);
            usb30d.DIOWrite(1, 0);
            System.Threading.Thread.Sleep(100);
            frame = 0;

            label6.Text = "Frame: " + frame.ToString();
            tbFileName.Text = path + "frame" + frame.ToString() + ".txt";
        }

    }
}
